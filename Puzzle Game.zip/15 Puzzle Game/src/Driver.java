/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ahsan Riaz
 */
public class Driver {
    public static void main(String[] args) {
        System.out.println("testing");
        //Create object of Board GUI
        BoardGUI g = new BoardGUI();
        // when all puzzle will be solved then game will show game win msg
    }
}